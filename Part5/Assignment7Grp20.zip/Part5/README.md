COA Assignment 7: Group 20
By Sourodeep Datta, Mihir Mallick

The Assembler folder contains the assembler for the ISA.
The Processor folder contains the verilog and memory files for the processor.
The TestCases folder contains 2 testcases for the processor, which are Boothes and GCD for the inputs 12 and 28.

To run boothes, run "make boothe"
To run gcd, run "make gcd"
To clean the files, run "make clean"